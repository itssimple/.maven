package se.itssimple.obsidianweave.fabric.platform;

import se.itssimple.obsidianweave.platform.IPlatformItemHelper;

import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Fabric-specific item helper for Obsidian Weave.
 * Handles item registration using Fabric's registry system.
 */
public class FabricItemHelper implements IPlatformItemHelper {
    /**
     * The mod ID for item registration.
     */
    private String modId;

    /**
     * Initializes the item helper for the given mod ID.
     * @param modId The mod ID to register items for.
     */
    @Override
    public void initialize(String modId) {
        this.modId = modId;
    }

    /**
     * Registers an item with the given name and supplier.
     * @param name The item name.
     * @param itemSupplier The item supplier.
     * @return A supplier for the registered item.
     */
    @Override
    public <T extends class_1792> Supplier<T> registerItem(String name, Supplier<T> itemSupplier)
    {
        T item = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(modId, name), itemSupplier.get());
        return () -> item;
    }
}
